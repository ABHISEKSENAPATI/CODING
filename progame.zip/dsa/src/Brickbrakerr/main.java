package Brickbrakerr;
import javax.swing.*;
public class main {

	public static void main(String[] args) {
		JFrame obj=new JFrame();
		gameplay Gameplay=  new gameplay();
		obj.setBounds(10,10, 700, 600);
		obj.setTitle("Break out ball");
		obj.setResizable(false);
		obj.setVisible(true);
		obj.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		obj.add(Gameplay);
		obj.addKeyListener(Gameplay);

	}

}
